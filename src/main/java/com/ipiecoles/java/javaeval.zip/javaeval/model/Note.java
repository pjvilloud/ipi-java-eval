package com.ipiecoles.java.javaeval.model;

/**
 * Created by pjvilloud on 27/09/17.
 */
public enum Note {
    INSUFFISANT,
    PASSABLE,
    BIEN,
    TRES_BIEN
}
