package com.ipiecoles.java.javaeval.repository;

import com.ipiecoles.java.javaeval.model.Manager;

public interface CommercialRepository extends BaseEmployeRepository<Manager> {

}
